-- phpMyAdmin SQL Dump
-- version 3.2.2.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 25. April 2010 um 18:53
-- Server Version: 5.1.37
-- PHP-Version: 5.2.10-2ubuntu6.4

--
-- Maik
--
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `Data`
--
CREATE DATABASE `Data` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `Data`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `1.13.021.6xx Endprüfung + Körperschallprüfung`
--

CREATE TABLE IF NOT EXISTS `1.13.021.6xx Endprüfung + Körperschallprüfung` (
  `Name` varchar(20) DEFAULT NULL,
  `Personalnummer` varchar(20) DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `Zeit` time DEFAULT NULL,
  `Gesamt Produzierte Menge` int(12) DEFAULT NULL,
  `Isolation` int(10) DEFAULT NULL,
  `Körperschall` int(10) DEFAULT NULL,
  `Sturz Motor` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `1.13.021.6xx Endprüfung + Körperschallprüfung`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `1.13.021.6xx Motormontage komplett (Automat)`
--

CREATE TABLE IF NOT EXISTS `1.13.021.6xx Motormontage komplett (Automat)` (
  `Name` varchar(20) DEFAULT NULL,
  `Personalnummer` varchar(20) DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `Zeit` time DEFAULT NULL,
  `Gesamt Produzierte Menge` int(12) DEFAULT NULL,
  `Ausschussstation 5` int(10) DEFAULT NULL,
  `Einlegefehler Motor` int(10) DEFAULT NULL,
  `Kameraerkennung - LS-B n.i.O.` int(10) DEFAULT NULL,
  `Messwerte außer Toleranz` int(10) DEFAULT NULL,
  `Montagefehler` int(10) DEFAULT NULL,
  `Spritzfehler LS-A` int(10) DEFAULT NULL,
  `Störung Motormontage` int(10) DEFAULT NULL,
  `Sturz Motor` int(10) DEFAULT NULL,
  `Ritzelaufziehkraft zu hoch` int(10) DEFAULT NULL,
  `Ritzelaufziehkraft zu niedrig` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `1.13.021.6xx Motormontage komplett (Automat)`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `1.13.021.6xx Schweißen Litzen`
--

CREATE TABLE IF NOT EXISTS `1.13.021.6xx Schweißen Litzen` (
  `Name` varchar(20) DEFAULT NULL,
  `Personalnummer` varchar(20) DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `Zeit` time DEFAULT NULL,
  `Gesamt Produzierte Menge` int(12) DEFAULT NULL,
  `Litze beschädigt` int(10) DEFAULT NULL,
  `Lötfahne verbogen` int(10) DEFAULT NULL,
  `Schweißung n.i.O.` int(10) DEFAULT NULL,
  `Sturz Motor` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `1.13.021.6xx Schweißen Litzen`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `21126701 Montage Gehäuse u. Lagerschild-A`
--

CREATE TABLE IF NOT EXISTS `21126701 Montage Gehäuse u. Lagerschild-A` (
  `Name` varchar(20) DEFAULT NULL,
  `Personalnummer` varchar(20) DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `Zeit` time DEFAULT NULL,
  `Gesamt Produzierte Menge` int(12) DEFAULT NULL,
  `Getaumeltes Lagerschild ohne Kugellager` int(10) DEFAULT NULL,
  `Kugellager nicht erkannt` int(10) DEFAULT NULL,
  `Prüfstempel zieht Kugellager aus Lagerschild` int(10) DEFAULT NULL,
  `Z1 (Bezugspunkt) außer Toleranz` int(10) DEFAULT NULL,
  `Z2 (Taumelmaß) außer Toleranz (Ausschuß)` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `21126701 Montage Gehäuse u. Lagerschild-A`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Datas`
--

CREATE TABLE IF NOT EXISTS `Datas` (
  `Name` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Maschinennummer` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Arbeitsgang` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Kostenstelle` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Werkzeug` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Datas`
--

INSERT INTO `Datas` (`Name`, `Maschinennummer`, `Arbeitsgang`, `Kostenstelle`, `Werkzeug`) VALUES
('21126701 Montage Gehäuse u. Lagerschild-A', '0', 'Montage Gehäuse u. Lagerschild-A', '1023', '0'),
('1.13.021.6xx Motormontage komplett (Automat)', '', 'Motormontage komplett (Automat)', '1023204', ''),
('1.13.021.6xx Schweißen Litzen', '', 'Schweißen Litzen', '1023204', ''),
('1.13.021.6xx Endprüfung + Körperschallprüfung', '', 'Endprüfung + Körperschallprüfung', '1023204', '');
